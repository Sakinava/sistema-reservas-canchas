/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.avance1;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author ashle
 */
@Controller
public class Controlador {

    @GetMapping({"/", "/login"})
    public String login() {
        return "login"; // Abre login.html
    }

    @PostMapping("/login")
    public String procesarLogin() {
        return "redirect:/menu"; // Al presionar ingresar, te manda al menú
    }

    @GetMapping("/menu")
    public String menu() {
        return "menu"; // Abre menu.html
    }
}

